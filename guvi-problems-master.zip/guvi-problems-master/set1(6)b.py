n=int(input())
if(n%4==0):
    print("yes")
else:
    print("no")
