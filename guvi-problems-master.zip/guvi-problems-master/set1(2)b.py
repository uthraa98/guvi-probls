n=int(input())
if(n%2==0):
    print("Even")
elif(n%2!=0):
    print("Odd")
else:
    print("invalid")
