n=int(input())
if(n>0):
    print("Positive")
elif(n<0):
    print("Negative")
else:
    print("Zero")
    
