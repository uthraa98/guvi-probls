ch =input()[0]
if ch.isalpha():
    print("Alphabet")
else:
    print("No")
