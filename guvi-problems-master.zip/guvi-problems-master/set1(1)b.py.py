n=int(input())
if(n>0):
    print("positive")
elif(n<0):
    print("negative")
else:
    print("zero")
    
